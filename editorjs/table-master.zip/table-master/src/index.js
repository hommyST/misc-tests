import Plugin from './plugin';
import './styles/index.pcss';

export default Plugin;
