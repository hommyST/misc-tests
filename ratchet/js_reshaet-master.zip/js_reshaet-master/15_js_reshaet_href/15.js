// Найти сумму чисел от 0 до 100 (включительно). (0+1+2+3+4+5).

let sum = 0;
for (let i=0; i<=100; i++){
	sum = sum + i;
	// sum += i;
}
console.log(sum);

