let hash = new hashGenerator(40);
console.log (hash.hash);