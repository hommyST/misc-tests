// С помощью цикла вывести произведение чисел от 1 до 50.
//1*2*3

let mult = 1;

for (let i=1; i<=3; i++){
	mult = mult * i;
	// sum += i;
}
console.log(mult);

